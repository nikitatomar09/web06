var express = require('express');
var router = express.Router();


const indexCtrl = require("../controllers/index.js");

router.get('/', indexCtrl.getHomePage);
router.get('/about', indexCtrl.getAbout);
router.get('/contact', indexCtrl.getContact);
router.get('/login', indexCtrl.getLogin);


module.exports = router;
