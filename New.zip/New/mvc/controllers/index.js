const getHomePage = function(req, res, next) {
    res.render('index', {title: "homepage"});
}

const getAbout = function(req, res, next) {
    res.render('about', {title: "about"});
}

const getContact = function(req, res, next) {
    res.render('contact', {title: "contact"});
}

const getLogin = function(req, res, next) {
    res.render('login', {title: "login"});
}

module.exports = {
    getHomePage,
    getAbout,
    getContact,
    getLogin
}